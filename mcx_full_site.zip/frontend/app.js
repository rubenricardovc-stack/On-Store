function addToCart(name, price) {
  let cart = JSON.parse(localStorage.getItem('ec_cart') || '[]');
  cart.push({name, price, qty:1});
  localStorage.setItem('ec_cart', JSON.stringify(cart));
  alert(name + ' adicionado ao carrinho!');
}

function renderCart() {
  let cart = JSON.parse(localStorage.getItem('ec_cart') || '[]');
  let html = '';
  let total = 0;
  cart.forEach(item => {
    html += `<div>${item.name} - ${item.price} AOA</div>`;
    total += item.price * item.qty;
  });
  document.getElementById('cart-items').innerHTML = html;
  document.getElementById('cart-total').textContent = total;
}

if (document.getElementById('cart-items')) {
  renderCart();
  document.getElementById('mcx-button').addEventListener('click', async () => {
    const cart = JSON.parse(localStorage.getItem("ec_cart") || "[]");
    const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
    const orderId = Date.now();

    document.getElementById('mcx-status').textContent = 'A iniciar pagamento MCX...';

    // Troca pelo URL real do backend (Render, Railway, Heroku, VPS, etc.)
    const backendUrl = "https://SEU_BACKEND_URL";

    try {
      const resp = await fetch(`${backendUrl}/create-mcx-payment`, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ total, orderId })
      });

      const data = await resp.json();
      if (data.success) {
        document.getElementById("mcx-status").innerHTML = `
          <p>Escaneie o QR Code no app MCX Express:</p>
          <img src="${data.qrCode}" alt="QR Code MCX">
          <p>Ou clique no link: <a href="${data.link}" target="_blank">Abrir no MCX</a></p>
        `;
      } else {
        document.getElementById("mcx-status").textContent = "Erro ao criar pagamento.";
      }
    } catch (err) {
      document.getElementById("mcx-status").textContent = "Falha na ligação ao backend.";
    }
  });
}
