# Loja+ Backend (MCX Express)

Este é o backend Node.js para integração real com o MCX Express.

## Como usar
1. Instale as dependências:
   ```bash
   npm install
   ```
2. Configure as variáveis de ambiente em `.env` (baseado no `.env.example`).
3. Inicie o servidor:
   ```bash
   npm start
   ```
4. Deploy recomendado: Render, Railway, Heroku ou VPS.

## Endpoints
- `POST /create-mcx-payment` → cria um pagamento no MCX Express
- `POST /mcx-callback` → recebe notificações da EMIS
- `GET /health` → rota de saúde
