require('dotenv').config();
const express = require('express');
const axios = require('axios');
const app = express();

app.use(express.json());

// Endpoint para criar pagamento MCX
app.post('/create-mcx-payment', async (req, res) => {
  const { total, orderId } = req.body;

  try {
    // Exemplo de chamada à API do MCX (substituir pelo endpoint real da EMIS)
    const response = await axios.post(process.env.MCX_API_BASE + '/payments', {
      clientId: process.env.MCX_CLIENT_ID,
      secret: process.env.MCX_CLIENT_SECRET,
      amount: total,
      orderId: orderId,
      callbackUrl: process.env.CALLBACK_BASE + '/mcx-callback'
    });

    res.json({
      success: true,
      qrCode: response.data.qrCode || 'https://via.placeholder.com/200',
      link: response.data.link || 'https://mcx-express.test/pagamento'
    });
  } catch (err) {
    console.error(err.message);
    res.json({ success: false, error: err.message });
  }
});

// Endpoint callback (webhook)
app.post('/mcx-callback', (req, res) => {
  console.log("Pagamento confirmado: ", req.body);
  res.sendStatus(200);
});

app.get('/health', (req, res) => {
  res.send('MCX Backend ativo');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('Servidor iniciado na porta ' + PORT));
