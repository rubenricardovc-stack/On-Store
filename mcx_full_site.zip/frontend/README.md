# Loja+ Frontend (MCX Express)

Este é o frontend estático da loja com integração MCX Express.

## Estrutura
- `index.html` → página inicial
- `products.html` → listagem de produtos
- `cart.html` → carrinho e checkout MCX
- `app.js` → lógica do carrinho e chamada ao backend

## Como usar
1. Hospedar estes ficheiros em GitHub Pages, Netlify, Vercel ou qualquer hosting estático.
2. Editar `app.js` e substituir `https://SEU_BACKEND_URL` pelo domínio real do backend Node.js (Render, Railway, Heroku ou VPS).
3. Ao clicar em "Pagar com MCX Express", o frontend envia um pedido ao backend para criar o pagamento.
4. O backend responde com QR Code e link MCX, que são exibidos ao utilizador.
